+{
   locale_version => 1.25,
   entry => <<'ENTRY', # for DUCET v9.0.0
0149      ; [.1DB9.0020.0009] # LATIN SMALL LETTER N PRECEDED BY APOSTROPHE
ENTRY
};
